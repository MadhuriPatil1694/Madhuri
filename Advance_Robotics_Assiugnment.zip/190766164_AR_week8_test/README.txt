# Cod\e Developed by Madhuri Ramesh Patil.

#Follow the steps to run the package: 


	1)git clone -b melodic-devel https://github.com/ros-planning/moveit_tutorials.git
	2)git clone -b melodic-devel https://github.com/ros-planning/panda_moveit_config.git

# UNzip the AR_week8_test.zip folder in src folder of your ctaking.

# Build the workspace using 'catkin_make'

#Run the following codes each on a new terminal:
	1) roslaunch panda_moveit_config demo.launch
	2) rosrun AR_week8_test square_size_generator.py
	3) rosrun AR_week8_test move_panda_square.py
	4) rosrun rqt_plot rqt_plot

