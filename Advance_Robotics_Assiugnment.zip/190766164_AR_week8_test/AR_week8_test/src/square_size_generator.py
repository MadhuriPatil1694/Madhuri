#!/usr/bin/env python
# license removed for brevity
import rospy
from std_msgs.msg import Float64
import random


def talker():
    pub = rospy.Publisher('randvalgen', Float64, queue_size=10)
    rospy.init_node('radval_generator', anonymous=True)
    rate = rospy.Rate(0.05) # 20sec

    while not rospy.is_shutdown():
        side_size = random.uniform(0.05, 0.20)
        rospy.loginfo(side_size)
        pub.publish(side_size)
        rate.sleep()

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass
