# Note This code is only supported for MacOS and Linux OS #

# ------- Required libraries ------------ #

1. bert-extractive-summarizer
2. spacy==2.1.3
3. transformers==2.2.2
4. neuralcoref
5. python -m spacy download en_core_web_md
6. rouge-score
7. textstat
8. requests
9. BeautifulSoup
10. FreeProxy
11. Selenium along with web driver specific to OS(Linux or MacOS)
12. pandas
13. numpy

# ----------- Files included in package ----------- #

1. chromedriver - Installed version is for MacOS for Linux replace it with linux chromedriver.

2. DocParse2.py - This contains code for web scrapping, downloading pdfs and extracting abstracts from websites. 
For parsing paper from a specific topic:
Replace inputstr on line 24 with the topic.

# - Note : Repeated use may cause blocking by google scholar resulting empty pdfs and needs a cooling off period of over 24 hours. The blocking is sometimes even observed getting over 30 pages of search results. Hence a prepared data is provided in backup abstracts for running summarisation.py for obtaining the summary.


3. file_Read.py - Used for extracting abstracts from pdfs. Need to run after DocParse2.py

For running for a specific topic:
change the string named Topic on line 5 with the desired topic.

4. Summarization.py - This file is used for obtaining summary for a specific topic. It works on abstracts in CSV file given by the above two codes which is taken as input to summariser. In event of blocking and unavailability of data in CSVs pre parsed CSVs for each topic are placed in backup folder just replace 'topic_name_abstracts.csv' in the folder named on topic of search once replaced you can run the summariser on the data.



