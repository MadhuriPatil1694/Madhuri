###### README #######

# Code is written in python 3.6
# tensorflow version is 1.14.0
# It requires other libraries like keras,matplotlib, numpy.

# GoogleNet.py contains code for GoogleNet and VGG_MinSub.py contains VGG implementation.