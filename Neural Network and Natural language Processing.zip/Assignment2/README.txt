following are the Scripts for this assignment:
Lab8_code:to compile this file we need 'data.30.en' and 'data.30.vi' in path
Lab10_code:to compile this file we need python file'tokenization' in path
Lab11&12_code:to compile this we need zipped folder 'swda'and file'tokenization'in path

1.15 tensorflow version is required in Lab10_code and Lab11&12_code
Assignment2_Report contains code and explaination